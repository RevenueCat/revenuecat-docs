---
title: "Customer Lists"
slug: "customer-lists-1"
hidden: false
createdAt: "2022-06-24T13:13:14.597Z"
updatedAt: "2022-06-24T13:13:14.597Z"
type: "link"
link_url: "https://www.revenuecat.com/docs/customer-lists"
---
