---
title: "What is a Customer?"
slug: "what-is-a-customer"
hidden: true
createdAt: "2022-06-24T13:13:50.341Z"
updatedAt: "2022-10-31T13:46:21.413Z"
---
Users, Customers, Subscribers, Installs... what are they, and what do they mean?