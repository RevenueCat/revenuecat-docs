---
title: "Configuring Server Notifications"
slug: "configuring-server-notifications"
hidden: false
createdAt: "2022-06-22T17:53:39.755Z"
updatedAt: "2022-06-22T17:55:06.771Z"
type: "link"
link_url: "https://www.revenuecat.com/docs/server-notifications"
---
