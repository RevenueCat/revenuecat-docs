---
title: "Configuring Projects and Apps"
slug: "create-a-project"
hidden: false
createdAt: "2022-11-16T21:35:15.349Z"
updatedAt: "2022-11-16T21:39:00.261Z"
type: "link"
link_url: "https://docs.revenuecat.com/docs/projects"
---
