---
title: "Identifying Users"
slug: "identifying-users"
hidden: false
createdAt: "2022-06-22T17:49:58.720Z"
updatedAt: "2022-06-22T17:49:58.720Z"
type: "link"
link_url: "https://www.revenuecat.com/docs/user-ids"
---
