---
title: "Test Snippets Synced from GitHub"
slug: "test_snippets_sync_from_github"
excerpt: "Update your docs automatically with `rdme`, ReadMe's official CLI and GitHub Action!"
hidden: true
createdAt: "2022-12-01T15:38:57.843Z"
updatedAt: "2022-12-01T17:20:53.627Z"
---
###  Test Snippets synced from local code

This was synced from GitHub actions when merging to main


```swift
// some swift code here
class Foo { 
    let bar: Bar
}
```
```kotlin
// here goes the kotlin equivalent
```