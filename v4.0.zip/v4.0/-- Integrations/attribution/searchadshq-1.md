---
title: "SearchAdsHQ"
slug: "searchadshq-1"
hidden: false
createdAt: "2022-06-02T21:07:09.989Z"
updatedAt: "2022-06-02T21:07:09.989Z"
type: "link"
link_url: "https://www.revenuecat.com/docs/splitmetrics-acquire"
---
