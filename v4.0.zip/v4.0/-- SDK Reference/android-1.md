---
title: "Android Reference"
slug: "android-1"
hidden: false
createdAt: "2018-12-12T20:00:40.637Z"
updatedAt: "2022-02-01T13:32:25.425Z"
type: "link"
link_url: "https://sdk.revenuecat.com/android/index.html"
---
