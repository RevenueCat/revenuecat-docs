---
title: "Cordova Reference"
slug: "cordova-reference"
hidden: false
createdAt: "2022-07-28T20:04:53.537Z"
updatedAt: "2022-07-28T20:04:53.537Z"
type: "link"
link_url: "https://revenuecat.github.io/cordova-plugin-purchases-docs/"
---
