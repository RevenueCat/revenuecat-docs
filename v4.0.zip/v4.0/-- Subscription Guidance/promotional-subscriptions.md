---
title: "Promotional Subscriptions"
slug: "promotional-subscriptions"
hidden: false
createdAt: "2022-08-16T13:57:03.093Z"
updatedAt: "2022-08-16T13:57:03.093Z"
type: "link"
link_url: "https://www.revenuecat.com/docs/promotionals"
---
