---
title: "Experiments redirect"
slug: "experiments-beta"
hidden: true
createdAt: "2020-09-15T23:42:30.804Z"
updatedAt: "2020-09-15T23:42:30.804Z"
type: "link"
link_url: "https://www.revenuecat.com/docs/experiments"
---
